<?php
/*
 * Plugin Name: 下载资源工具
 * Plugin URI: https://github.com/xiaofangkuai521
 * Description: 一个用于展示下载资源的插件，可以自定义标题、下载链接、描述，并通过复选框控制是否显示，点击下载按钮时弹出弹窗显示描述信息，点击下载按钮直接跳转。
 * Version: 1.3
 * Author: 小方块
 * Author URI: https://github.com/xiaofangkuai521
 * License: GPL v2 or later
 */

// 防止直接访问插件文件
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


function download_resource_meta_box() {
    add_meta_box(
        'download_resource_meta_box',
        '下载资源设置',
        'download_resource_meta_box_content',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'download_resource_meta_box');


function download_resource_meta_box_content($post) {

    $title = get_post_meta($post->ID, '_download_resource_title', true);
    $link = get_post_meta($post->ID, '_download_resource_link', true);
    $description = get_post_meta($post->ID, '_download_resource_description', true);
    $show_resource = get_post_meta($post->ID, '_download_resource_show', true);


    wp_nonce_field('download_resource_nonce_action', 'download_resource_nonce_field');

    ?>
    <p>
        <label for="download_resource_title">网盘名称:</label>
        <input type="text" id="download_resource_title" name="download_resource_title" class="widefat" value="<?php echo esc_attr($title); ?>" />
    </p>
    <p>
        <label for="download_resource_link">下载链接:</label>
        <input type="text" id="download_resource_link" name="download_resource_link" class="widefat" value="<?php echo esc_attr($link); ?>" />
    </p>
    <p>
        <label for="download_resource_description">资源描述:</label>
        <textarea id="download_resource_description" name="download_resource_description" class="widefat"><?php echo esc_textarea($description); ?></textarea>
    </p>
    <p>
        <label for="download_resource_show">显示下载资源:</label>
        <input type="checkbox" id="download_resource_show" name="download_resource_show" value="1" <?php checked($show_resource, 1); ?> />
        <span>勾选此框以显示下载资源工具</span>
    </p>
    <?php
}


function save_download_resource_meta($post_id) {

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return $post_id;


    if (!isset($_POST['download_resource_nonce_field']) || !wp_verify_nonce($_POST['download_resource_nonce_field'], 'download_resource_nonce_action')) {
        return $post_id;
    }


    if (isset($_POST['download_resource_title'])) {
        update_post_meta($post_id, '_download_resource_title', sanitize_text_field($_POST['download_resource_title']));
    }
    if (isset($_POST['download_resource_link'])) {
        update_post_meta($post_id, '_download_resource_link', sanitize_text_field($_POST['download_resource_link']));
    }
    if (isset($_POST['download_resource_description'])) {
        update_post_meta($post_id, '_download_resource_description', sanitize_textarea_field($_POST['download_resource_description']));
    }
    if (isset($_POST['download_resource_show'])) {
        update_post_meta($post_id, '_download_resource_show', 1);
    } else {
        update_post_meta($post_id, '_download_resource_show', 0);
    }

    return $post_id;
}
add_action('save_post', 'save_download_resource_meta');


function display_download_resource_tool($content) {
    if (is_single()) {
        global $post;


        $show_resource = get_post_meta($post->ID, '_download_resource_show', true);
        if ($show_resource) {
            $title = get_post_meta($post->ID, '_download_resource_title', true);
            $link = get_post_meta($post->ID, '_download_resource_link', true);
            $description = get_post_meta($post->ID, '_download_resource_description', true);


            $button_text = $title ? esc_html($title) : '下载资源';


            $resource_html = '
                <div class="download-resource-tool">
                    <button class="download-button" onclick="showDescription()">' . $button_text . '</button>
                </div>

                <div id="description-modal" class="modal">
                    <div class="modal-content" onclick="event.stopPropagation()">
                        <span class="close" onclick="closeDescription()">&times;</span>
                        <h3>' . esc_html($title) . '</h3>
                        <p>' . esc_textarea($description) . '</p>
                        <a href="' . esc_url($link) . '" class="download-link" target="_blank">点击下载</a>
                    </div>
                </div>

                <script>
                    function showDescription() {
                        document.getElementById("description-modal").style.display = "block";
                    }
                    function closeDescription() {
                        document.getElementById("description-modal").style.display = "none";
                    }

                    // 当点击弹窗外的区域时，关闭弹窗
                    window.onclick = function(event) {
                        var modal = document.getElementById("description-modal");
                        if (event.target == modal) {
                            closeDescription();
                        }
                    }
                </script>
            ';


            $content .= $resource_html;
        }
    }

    return $content;
}
add_filter('the_content', 'display_download_resource_tool');


function download_resource_tool_enqueue_styles() {
    wp_register_style('download_resource_tool_style', false);
    wp_enqueue_style('download_resource_tool_style');
    wp_add_inline_style('download_resource_tool_style', '
        .download-resource-tool {
            margin-top: 20px;
        }

        .download-resource-tool .download-button {
            background-color: #0073e6;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }

        .download-resource-tool .download-button:hover {
            background-color: #005bb5;
        }

        /* Modal (弹窗) 样式 */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0,0,0);
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 15% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 10px;
        }

        .modal .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            position: absolute;
            top: 0;
            right: 10px;
        }

        .modal .close:hover,
        .modal .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .modal .download-link {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #0073e6;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }

        .modal .download-link:hover {
            background-color: #005bb5;
        }
    ');
}
add_action('wp_enqueue_scripts', 'download_resource_tool_enqueue_styles');
